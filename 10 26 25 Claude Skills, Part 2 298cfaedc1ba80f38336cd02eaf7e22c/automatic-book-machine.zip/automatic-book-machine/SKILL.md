---
name: automatic-book-machine
description: Automated novel generation system that creates complete books from scratch. Generates premise, characters, outline, and writes minimum 10 chapters with plan-draft-edit cycles. Use when user requests automatic book creation, full novel generation, or multi-chapter story writing with systematic workflow.
---

# Automatic Book Machine

Automated system for generating complete novels from scratch through structured phases and loops.

## Workflow Overview

Execute in strict sequential order:

1. **PHASE 1: Foundation** - Generate premise, characters, outline (complete before writing)
2. **PHASE 2: Chapter Loop** - For each chapter: plan → draft → edit plan → final
3. **Completion** - Continue until minimum 10 chapters with resolved arcs

## Critical Requirements

**Tagging discipline:**
- Every section MUST use square bracket tags: `[section name]` content `[/section name]`
- Tags are case-sensitive and must match exactly
- Never skip a required tag
- Complete all tags for one chapter before starting the next

**Sequential execution:**
- Never skip ahead or work out of order
- Complete entire phase/section before proceeding
- Each chapter requires all four tags (plan, draft, edit plan, final)

**Adult fiction standards:**
- Target audience: 25-45 years old
- Sophisticated prose and complex characters
- Mature themes appropriate for adult readership

## PHASE 1: Foundation

Complete all three sections before writing any chapters.

### 1.1 Premise Development

`[premise development]`

Generate:
- **Core concept/hook** - Compelling central idea
- **Genre and subgenre** - Primary and secondary categories
- **Thematic elements** - 2-4 core themes to explore
- **Target word count** - Estimated total length
- **Audience positioning** - Adult fiction (25-45)

`[/premise development]`

### 1.2 Character Creation

`[character creation]`

For 3-5 major characters, document:
- **Name, age (25+), physical description**
- **Core personality traits** - 3-5 defining characteristics
- **Background/history** - Formative experiences
- **Goals and motivations** - What they want and why
- **Internal conflicts** - Personal struggles
- **Character arc trajectory** - How they'll change
- **Relationships** - Connections to other characters

`[/character creation]`

### 1.3 Story Outline

`[story outline]`

Create detailed structure:
- **Act breakdown** - Three-act or alternative structure
- **Chapter summaries** - 2-3 paragraphs per chapter (minimum 10 chapters)
- **Key plot beats** - Major events per chapter
- **Character arc milestones** - Development points
- **Pacing notes** - Tension/release rhythm

`[/story outline]`

## PHASE 2: Chapter Production Loop

Repeat this exact four-step cycle for each chapter. Never skip steps or tags.

### Step 1: Planning

`[chapter X plan]`

Before drafting, detail:
- **Chapter goals** - Plot advancement, character development, thematic exploration
- **Scene breakdown** - Setting, POV, key events for each scene
- **Emotional beats** - Feelings/tensions to evoke
- **Pacing strategy** - Fast/slow sections, tension building
- **Target word count** - Approximate length
- **Connections** - Links to previous chapter and setup for next
- **Research/worldbuilding** - Specific details needed

`[/chapter X plan]`

### Step 2: Drafting

`[chapter X draft]`

Write complete chapter following the plan:
- Maintain consistent voice and style
- Apply genre conventions
- Show don't tell
- Balance dialogue, action, description, interiority
- Implement planned scenes and beats

`[/chapter X draft]`

### Step 3: Edit Planning

`[chapter X edit plan]`

Analyze draft and identify improvements:
- **Pacing issues** - Slow/rushed sections requiring adjustment
- **Character voice** - Consistency problems or OOC moments
- **Plot/continuity** - Logic gaps, contradictions, timeline errors
- **Prose weaknesses** - Filter words, passive voice, clichés, awkward phrasing
- **Dialogue** - Authenticity, character distinction, on-the-nose problems
- **Transitions** - Rough scene changes or jumps
- **Emotional resonance** - Beats that fell flat or need strengthening
- **Line-level fixes** - Specific sentences/paragraphs needing revision

`[/chapter X edit plan]`

### Step 4: Final Draft

`[chapter X final]`

Execute all improvements from edit plan. Produce publication-ready chapter:
- Address every issue identified in edit plan
- Polish prose to professional standard
- Ensure continuity with previous chapters
- Verify all planned elements delivered

`[/chapter X final]`

### Step 5: Loop Continuation

Immediately begin `[chapter X+1 plan]` and repeat entire cycle.

## Execution Standards

**Continuity tracking:**
- Maintain character consistency (appearance, traits, relationships)
- Track plot threads and foreshadowing
- Preserve worldbuilding details
- Note timeline and causality

**Quality benchmarks:**
- Edit phase must meaningfully improve draft (not rubber-stamp)
- Each chapter should be structurally sound independently
- Progressive character development across chapters
- Escalating stakes and tension

**No gaps policy:**
- Every chapter must have all four required sections
- Tags must be properly opened and closed
- Never skip ahead to later chapters

## Completion Criteria

Novel is complete when:
- ✓ Foundation phase finished (premise, characters, outline)
- ✓ Minimum 10 chapters produced
- ✓ Each chapter has all 4 sections (plan, draft, edit plan, final)
- ✓ Main story arc resolved
- ✓ Character arcs concluded satisfactorily

## Triggering the Workflow

When user requests automatic book generation:
1. Confirm genre/premise or generate automatically
2. State you're beginning PHASE 1
3. Execute workflow without stopping until completion or user intervention
4. Produce all required tags in proper format

Begin with `[premise development]` immediately upon activation.
